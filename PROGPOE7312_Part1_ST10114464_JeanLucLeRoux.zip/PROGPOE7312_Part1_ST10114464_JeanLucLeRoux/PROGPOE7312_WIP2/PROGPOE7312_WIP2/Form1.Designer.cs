﻿
namespace PROGPOE7312_WIP2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnRepBooks = new System.Windows.Forms.Button();
            this.btnSortBooks = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lstCallNumbers = new System.Windows.Forms.ListBox();
            this.lblPoints = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.timerGame = new System.Windows.Forms.Timer(this.components);
            this.txtCallNumber = new System.Windows.Forms.TextBox();
            this.txtAuthorName = new System.Windows.Forms.TextBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnMoveUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRepBooks
            // 
            this.btnRepBooks.Location = new System.Drawing.Point(99, 272);
            this.btnRepBooks.Name = "btnRepBooks";
            this.btnRepBooks.Size = new System.Drawing.Size(102, 23);
            this.btnRepBooks.TabIndex = 0;
            this.btnRepBooks.Text = "Replace Books";
            this.btnRepBooks.UseVisualStyleBackColor = true;
            this.btnRepBooks.Click += new System.EventHandler(this.btnRepBooks_Click);
            // 
            // btnSortBooks
            // 
            this.btnSortBooks.Location = new System.Drawing.Point(223, 272);
            this.btnSortBooks.Name = "btnSortBooks";
            this.btnSortBooks.Size = new System.Drawing.Size(98, 23);
            this.btnSortBooks.TabIndex = 1;
            this.btnSortBooks.Text = "Sort Books";
            this.btnSortBooks.UseVisualStyleBackColor = true;
            this.btnSortBooks.Click += new System.EventHandler(this.btnSortBooks_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(162, 345);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(83, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "EXIT GAME";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lstCallNumbers
            // 
            this.lstCallNumbers.AllowDrop = true;
            this.lstCallNumbers.FormattingEnabled = true;
            this.lstCallNumbers.Location = new System.Drawing.Point(99, 87);
            this.lstCallNumbers.Name = "lstCallNumbers";
            this.lstCallNumbers.Size = new System.Drawing.Size(222, 160);
            this.lstCallNumbers.TabIndex = 3;
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.Location = new System.Drawing.Point(99, 38);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(39, 13);
            this.lblPoints.TabIndex = 4;
            this.lblPoints.Text = "Points:";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(268, 38);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(36, 13);
            this.lblTimer.TabIndex = 5;
            this.lblTimer.Text = "Timer:";
            // 
            // timerGame
            // 
            this.timerGame.Enabled = true;
            this.timerGame.Tick += new System.EventHandler(this.timerGame_Tick);
            // 
            // txtCallNumber
            // 
            this.txtCallNumber.Location = new System.Drawing.Point(567, 87);
            this.txtCallNumber.Name = "txtCallNumber";
            this.txtCallNumber.Size = new System.Drawing.Size(100, 20);
            this.txtCallNumber.TabIndex = 6;
            // 
            // txtAuthorName
            // 
            this.txtAuthorName.Location = new System.Drawing.Point(567, 148);
            this.txtAuthorName.Name = "txtAuthorName";
            this.txtAuthorName.Size = new System.Drawing.Size(100, 20);
            this.txtAuthorName.TabIndex = 7;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(456, 87);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(75, 23);
            this.btnAddItem.TabIndex = 8;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(456, 144);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 9;
            this.btnRemove.Text = "Remove Item";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnMoveUp
            // 
            this.btnMoveUp.Location = new System.Drawing.Point(533, 217);
            this.btnMoveUp.Name = "btnMoveUp";
            this.btnMoveUp.Size = new System.Drawing.Size(75, 23);
            this.btnMoveUp.TabIndex = 10;
            this.btnMoveUp.Text = "Move Up";
            this.btnMoveUp.UseVisualStyleBackColor = true;
            this.btnMoveUp.Click += new System.EventHandler(this.btnMoveUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(635, 217);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(75, 23);
            this.btnDown.TabIndex = 11;
            this.btnDown.Text = "Move Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnMoveUp);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.txtAuthorName);
            this.Controls.Add(this.txtCallNumber);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.lblPoints);
            this.Controls.Add(this.lstCallNumbers);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSortBooks);
            this.Controls.Add(this.btnRepBooks);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRepBooks;
        private System.Windows.Forms.Button btnSortBooks;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lstCallNumbers;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.Label lblTimer;
        public System.Windows.Forms.Timer timerGame;
        private System.Windows.Forms.TextBox txtCallNumber;
        private System.Windows.Forms.TextBox txtAuthorName;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnMoveUp;
        private System.Windows.Forms.Button btnDown;
    }
}

