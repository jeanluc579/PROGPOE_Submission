﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROGPOE7312_WIP2
{
    public partial class Form1 : Form
    {
        private int remainingTime = 60; //Remaining time left in seconds

        private int points = 0;

        private bool isGameActive = false;

        private Timer tmrGame = new Timer();

        private List<string> authorNames = new List<string> { "Rudolf", "Shakespeare", "Smith", "Tolkien", "Cooper" };
        private int authorIndex = 0; //Keep track of the current author index


        public Form1()
        {
            InitializeComponent();

            //Initialise the timer
            timerGame.Interval = 1000;
            timerGame.Tick += timerGame_Tick;

            //Start the game when the form loads
            StartGame();

        }
        //----------------------------------------------------------------------------------------------------//

        //------------------------------------------------------------------------------------------------------//

        //https://www.youtube.com/watch?v=EmU7Jf4ZYq0
        private void AddItemToList()
        {
            string callNumber = txtCallNumber.Text;
            string authorName = txtAuthorName.Text;
            string item = $"{callNumber} {authorName}";

            if(!string.IsNullOrEmpty(callNumber) && !!string.IsNullOrEmpty(authorName))
            {
                lstCallNumbers.Items.Add(item);
                ClearTextBoxes();

            }
        }
        //--------------------------------------------------------------------------------------------------------//

        //----------------------------------------------------------------------------------------------------//
        private void RemoveSelectedItem()
        {
            if (lstCallNumbers.SelectedIndex != -1)
            {
                lstCallNumbers.Items.RemoveAt(lstCallNumbers.SelectedIndex);
            }
        }
        //-------------------------------------------------------------------------------------------------//

        //-----------------------------------------------------------------------------------------------//
        private void ClearTextBoxes()
        {
            txtCallNumber.Clear();
            txtAuthorName.Clear();
        }
        //-------------------------------------------------------------------------------------//

        //--------------------------------------------------------------------------------//
        private void moveItemDown()
        {
            int selectedIndex = lstCallNumbers.SelectedIndex;

            if(selectedIndex >= 0 && selectedIndex < lstCallNumbers.Items.Count - 1)
            {
                string selectedItem = lstCallNumbers.Items[selectedIndex].ToString();
                lstCallNumbers.Items.RemoveAt(selectedIndex);
                lstCallNumbers.Items.Insert(selectedIndex + 1, selectedItem);
                lstCallNumbers.SelectedIndex = selectedIndex + 1;
            }
        }
        //-------------------------------------------------------------------------------------------------//

        //-----------------------------------------------------------------------------------------------//
        private void moveItemUp()
        {
            int selectedIndex = lstCallNumbers.SelectedIndex;
            if(selectedIndex > 0)
            {
                string selectedItem = lstCallNumbers.Items[selectedIndex].ToString();
                lstCallNumbers.Items.RemoveAt(selectedIndex);
                lstCallNumbers.Items.Insert(selectedIndex - 1, selectedItem);
                lstCallNumbers.SelectedIndex = selectedIndex - 1;
            }
        }

        //-----------------------------------------------------------------------------------------------------//
        //https://www.youtube.com/watch?v=GNyeojGBqmQ
        private void timerGame_Tick(object sender, EventArgs e)
        {
            //Timer tick event handler
            remainingTime--;
            UpdateTimeLabel();

            if (remainingTime <= 0)
            {
                StopGame();
                MessageBox.Show($"Game Over! Your score is: {points}");
            }
        }
        //--------------------------------------------------------------------------------------------------//

        //----------------------------------------------------------------------------------------------------//
        private void StartGame()
        {
            //Starts a new game for the user
            isGameActive = true;
            points = 0;
            remainingTime = 60;
            UpdateTimeLabel();
            lblPoints.Text = $"Points: {points}";

            timerGame.Start();
            btnRepBooks.Enabled = true;
            btnSortBooks.Enabled = true;
        }
        //------------------------------------------------------------------------------------------//

        //------------------------------------------------------------------------------------------//
        private void StopGame()
        {
            //Stops the game for the user
            isGameActive = false;
            timerGame.Stop();
            btnRepBooks.Enabled = true;
            btnSortBooks.Enabled = false;

        }
        //--------------------------------------------------------------------------//

        //----------------------------------------------------------------------------//
        private void UpdateTimeLabel()
        {
            //Update the time label
            lblTimer.Text = $"Time: {remainingTime} seconds";

        }
        //-----------------------------------------------------------------------------//

        //----------------------------------------------------------------------------//
        private void btnRepBooks_Click(object sender, EventArgs e)
        {
            //Clears the list of call numbers
            lstCallNumbers.Items.Clear();

            //Generate 10 unique call numbers and authors
            List<string> uniqueCallNumbers = GenerateUniqueCallNumbers();

            //Shuffle the list to randomise the order
            ShuffleList(uniqueCallNumbers);

            //Adds shuffled items to the list box
            foreach (string callNumber in uniqueCallNumbers)
            {
                lstCallNumbers.Items.Add(callNumber);
            }
/*
            //Generate and display 10 random call numbers
            for (int i = 0; i < 10; i++)
            {
                string callNumber = GenerateRandomCallNumber();
                lstCallNumbers.Items.Add(callNumber);

            }
*/


            //Enables the 'sort' button
            btnSortBooks.Enabled = true;

            //Disable the 'Replace books' button
            btnRepBooks.Enabled = false;

        }

        //https://www.youtube.com/watch?v=aLhAmimoQj8
        //https://www.youtube.com/watch?v=vQzREQUhGSA
        //https://www.youtube.com/watch?v=AD2qzcYk7rI
        //https://www.youtube.com/watch?v=wHKlP8cov9w
        private List<string> GenerateUniqueCallNumbers()
        {
            //Generates unique call numbers and authors
            HashSet<string> generatedItems = new HashSet<string>();
            List<string> uniqueCallNumbers = new List<string>();

            Random random = new Random();
            string callNumber;

            //Shuffle the list of author names
            ShuffleList(authorNames);

            while (uniqueCallNumbers.Count < 10)
            {
                string author = authorNames[authorIndex];
                callNumber = $"{random.Next(1000):D3}.{random.Next(100):D2} {author}";

                //Increment the author inder or reset it if all authors have been used
                authorIndex = (authorIndex + 1) % authorNames.Count;

                if (generatedItems.Add(callNumber))
                {
                    uniqueCallNumbers.Add(callNumber);
                }
            }

            return uniqueCallNumbers;
        }


        //Different youtube videos I used to help me commeneted out
        //https://www.youtube.com/watch?v=H5LGwDanx2U
        //https://www.youtube.com/watch?v=4zx5bM2OcvA
        //https://www.youtube.com/watch?v=EvPVtKryspY
        private void ShuffleList<T>(List<T> list)
        {
            //This shuffles the itmes in the list using the Fisher-Yates algorithm
            Random random = new Random();
            int n = list.Count;
            for (int i = n - 1; i > 0; i--)
            {
                int x = random.Next(0, i + 1);
                T temp = list[i];
                list[i] = list[x];
                list[x] = temp;
            }
        }

        //---------------------------------------------------------------------------------------------------------//

        //------------------------------------------------------------------------------------------------------//

        private string GenerateRandomCallNumber()
        {
            HashSet<string> generatedCallNumbers = new HashSet<string>();

            Random random = new Random();
            string callNumber;
            //Trying to generate unique call numbers
            do
            {
                callNumber = $"{random.Next(1000):D3}.{random.Next(100):D2} {GenerateRandomName()}";
            }
            while (!generatedCallNumbers.Add(callNumber)); //The Add should return false if the call number already exists

            return callNumber;
        }
        //--------------------------------------------------------------------------------------------------------//

        //--------------------------------------------------------------------------------------------------------------//
        //https://www.youtube.com/watch?v=KvKEuKq4nhs
        //https://www.youtube.com/watch?v=NY6C8b2G62Q
        private string GenerateRandomName()
        {
            ////Generate random author names on the list
            string[] authors = { "Rudolf", "Shakespeare", "Smith", "Tolkien", "Cooper" };
            Random random = new Random();
            return authors[random.Next(authors.Length)];
        }
        //---------------------------------------------------------------------------------------------------//


        //----------------------------------------------------------------------------------------------------//
        private void btnSortBooks_Click(object sender, EventArgs e)
        {
            //Sort the displayed call numbers
            List<string> sortedCallNumbers = new List<string>();
            foreach (var item in lstCallNumbers.Items)
            {
                sortedCallNumbers.Add(item.ToString());

            }
            sortedCallNumbers.Sort();

            //Checks if the users sorting matches that on the list
            bool sortingCorrect = true;
            for(int i = 0; i < sortedCallNumbers.Count; i++)
            {
                if (lstCallNumbers.Items[i].ToString() != sortedCallNumbers[i])
                {
                    sortingCorrect = false;
                    break;
                }
            }
            //Displays a message based on if the user got it correct or incorrect
            if (sortingCorrect)
            {
                points += 10; //Awards 10 points for correct answers
                lblPoints.Text = $"Points: {points}";
                MessageBox.Show("That is correct!");
            }

            else
            {
                MessageBox.Show("That is incorrect!");
            }

            btnRepBooks.Enabled = true;

            btnSortBooks.Enabled = false;
        }
        //---------------------------------------------------------------------------------------------//

        //---------------------------------------------------------------------------------------------//
        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exit button for the user to close th program
            Application.Exit();
        }

        private void lstCallNumbers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            //Calling AddItemToList Method
            AddItemToList();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            RemoveSelectedItem();
        }

        private void btnMoveUp_Click(object sender, EventArgs e)
        {
            //Calling moveItemUp Method
            moveItemUp();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            moveItemDown();
        }
    }
}
//https://www.youtube.com/watch?v=S0GPI1mGT_A
