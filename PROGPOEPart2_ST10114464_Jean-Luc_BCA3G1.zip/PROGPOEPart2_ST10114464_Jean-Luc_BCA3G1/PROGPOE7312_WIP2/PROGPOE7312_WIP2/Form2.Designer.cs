﻿
namespace PROGPOE7312_WIP2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCallNum = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnAns = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.lstCatRight = new System.Windows.Forms.ListBox();
            this.lstCatWrng = new System.Windows.Forms.ListBox();
            this.btnExitGame = new System.Windows.Forms.Button();
            this.btnBackMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCallNum
            // 
            this.lblCallNum.AutoSize = true;
            this.lblCallNum.Location = new System.Drawing.Point(92, 29);
            this.lblCallNum.Name = "lblCallNum";
            this.lblCallNum.Size = new System.Drawing.Size(57, 13);
            this.lblCallNum.TabIndex = 0;
            this.lblCallNum.Text = "Categories";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(281, 29);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(33, 13);
            this.lblTime.TabIndex = 1;
            this.lblTime.Text = "Time:";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(473, 29);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(38, 13);
            this.lblScore.TabIndex = 2;
            this.lblScore.Text = "Score:";
            this.lblScore.Click += new System.EventHandler(this.lblScore_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(95, 321);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(102, 23);
            this.btn1.TabIndex = 3;
            this.btn1.Text = "Move answer 1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btnAns
            // 
            this.btnAns.Location = new System.Drawing.Point(216, 321);
            this.btnAns.Name = "btnAns";
            this.btnAns.Size = new System.Drawing.Size(98, 23);
            this.btnAns.TabIndex = 4;
            this.btnAns.Text = "Move answer 2";
            this.btnAns.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(476, 331);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(96, 23);
            this.btn3.TabIndex = 5;
            this.btn3.Text = "Move answer 3";
            this.btn3.UseVisualStyleBackColor = true;
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(612, 331);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(103, 23);
            this.btn4.TabIndex = 6;
            this.btn4.Text = "Move Answer 4";
            this.btn4.UseVisualStyleBackColor = true;
            // 
            // lstCatRight
            // 
            this.lstCatRight.FormattingEnabled = true;
            this.lstCatRight.Location = new System.Drawing.Point(95, 106);
            this.lstCatRight.Name = "lstCatRight";
            this.lstCatRight.Size = new System.Drawing.Size(219, 173);
            this.lstCatRight.TabIndex = 7;
            // 
            // lstCatWrng
            // 
            this.lstCatWrng.FormattingEnabled = true;
            this.lstCatWrng.Location = new System.Drawing.Point(476, 106);
            this.lstCatWrng.Name = "lstCatWrng";
            this.lstCatWrng.Size = new System.Drawing.Size(239, 173);
            this.lstCatWrng.TabIndex = 8;
            // 
            // btnExitGame
            // 
            this.btnExitGame.Location = new System.Drawing.Point(248, 402);
            this.btnExitGame.Name = "btnExitGame";
            this.btnExitGame.Size = new System.Drawing.Size(75, 23);
            this.btnExitGame.TabIndex = 9;
            this.btnExitGame.Text = "EXIT";
            this.btnExitGame.UseVisualStyleBackColor = true;
            this.btnExitGame.Click += new System.EventHandler(this.btnExitGame_Click);
            // 
            // btnBackMenu
            // 
            this.btnBackMenu.Location = new System.Drawing.Point(420, 402);
            this.btnBackMenu.Name = "btnBackMenu";
            this.btnBackMenu.Size = new System.Drawing.Size(75, 23);
            this.btnBackMenu.TabIndex = 10;
            this.btnBackMenu.Text = "BACK";
            this.btnBackMenu.UseVisualStyleBackColor = true;
            this.btnBackMenu.Click += new System.EventHandler(this.btnBackMenu_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBackMenu);
            this.Controls.Add(this.btnExitGame);
            this.Controls.Add(this.lstCatWrng);
            this.Controls.Add(this.lstCatRight);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btnAns);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblCallNum);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCallNum;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btnAns;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.ListBox lstCatRight;
        private System.Windows.Forms.ListBox lstCatWrng;
        private System.Windows.Forms.Button btnExitGame;
        private System.Windows.Forms.Button btnBackMenu;
    }
}