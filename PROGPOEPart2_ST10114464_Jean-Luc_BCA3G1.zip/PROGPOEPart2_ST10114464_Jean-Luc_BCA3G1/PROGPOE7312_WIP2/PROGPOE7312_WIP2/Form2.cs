﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PROGPOE7312_WIP2
{
    public partial class Form2 : Form
    {
        private Dictionary<string, string> deweyCategories; //Stores call numbers and descriptions
        private List<string> shuffledCategories; //Shuffles list of categories
        private int currentIndex; //Index to track the current category
        private int correctMatches; // Counter for correct matches
        private int totalMatches;// total number of matches
        private Timer timer;
        private Button[] buttons; //Delcaring array for buttons
        private int userScore = 0;


        public Form2()
        {
            InitializeComponent();
            InitializeGame();
            buttons = new Button[] { btn1, btnAns, btn3, btn4 };//
        }

        private void InitializeGame()
        {
            StartGame();//Starts the game

            //Initialise game variables
            deweyCategories = new Dictionary<string, string>
            {
                {"000", "Generalities" },
                {"100", "Philosophy" },
                {"200", "Religion" },
                {"300", "Social Sciences" },
                {"400", "Psychology" },
                {"500", "History" },

            };

            shuffledCategories = deweyCategories.Keys.ToList();
            ShuffleList(shuffledCategories);

            currentIndex = 0;
            correctMatches = 0;
            totalMatches = shuffledCategories.Count;

            //Start the timer
            timer = new Timer();
            timer.Interval = 1000; //1 second
            timer.Tick += Timer_Tick;
            timer.Start();

            DisplayQuestion();

        }

        private void DisplayQuestion()
        {
            if (currentIndex < shuffledCategories.Count)
            {
                //Display the current category
                lblCallNum.Text = shuffledCategories[currentIndex];

                List<string> possibleAnswers = new List<string>();
                possibleAnswers.Add(deweyCategories[shuffledCategories[currentIndex]]);

                // Add three random incorrect answers
                Random random = new Random();

                while (possibleAnswers.Count < 4)
                {
                    string randomCategory = shuffledCategories[random.Next (shuffleCategories.Count)];
                    if (!possibleAnswers.Contains(deweyCategories[randomCategory]))
                    {
                        possibleAnswers.Add(deweyCategories[randomCategory]);

                    }
                }

                //Shuffle the possible answers
                ShuffleList(possibleAnswers);

                //Display the possible answers
                for (int i = 0; i < 4; i++)
                {
                    buttons[i].Text = possibleAnswers[i];
                }
            }
            else
            {
                GameOver();
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Button selectedButton = (Button)sender;
            string userAnswer = selectedButton.Text;
            string correctAnswer = deweyCategories[shuffledCategories[currentIndex]];

            if (userAnswer == correctAnswer)
            {
                correctMatches++;
                userScore += 10; //Rewards 10 points for each correct answer
                lblScore.Text = $"Score: {userScore}";
            }
            currentIndex++;
            DisplayQuestion();
        }


        private void Timer_Tick (object sender, EventArgs e)
        {

        }

        private void GameOver()
        {
            timer.Stop();
            MessageBox.Show($"Game Over! Your Score is: {userScore}");
        }

        private void ShuffleList(List<string> list)
        {
            Random random = new Random();

            for (int i = list.Count -1; i > 0; i--)
            {
                int j = random.Next(0, i + 1);

                //Swap list[i] and list[j]
                string temp = list[i];
                list[i] = list[j];
                list[j] = temp;

            }
        }

        private void StartGame()
        {
            userScore = 0;
            currentIndex = 0;
            correctMatches = 0;
            DisplayQuestion();
        }

        private void lblScore_Click(object sender, EventArgs e)
        {

        }

        private void btnExitGame_Click(object sender, EventArgs e)
        {
            //Exit button for the user to close th program
            Application.Exit();
        }

        private void btnBackMenu_Click(object sender, EventArgs e)
        {
            // Creating an instance of the HomePage form
            HomePage homePage = new HomePage();

            //Show the homepage form
            homePage.Show();

            //Closes form1
            this.Hide();

            this.Close();
        }
    }
}
