﻿
namespace PROGPOE7312_WIP2
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBookGame = new System.Windows.Forms.Button();
            this.btnMatchGame = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBookGame
            // 
            this.btnBookGame.Location = new System.Drawing.Point(317, 74);
            this.btnBookGame.Name = "btnBookGame";
            this.btnBookGame.Size = new System.Drawing.Size(125, 82);
            this.btnBookGame.TabIndex = 0;
            this.btnBookGame.Text = "BOOK GAME";
            this.btnBookGame.UseVisualStyleBackColor = true;
            this.btnBookGame.Click += new System.EventHandler(this.btnBookGame_Click);
            // 
            // btnMatchGame
            // 
            this.btnMatchGame.Location = new System.Drawing.Point(317, 217);
            this.btnMatchGame.Name = "btnMatchGame";
            this.btnMatchGame.Size = new System.Drawing.Size(125, 89);
            this.btnMatchGame.TabIndex = 1;
            this.btnMatchGame.Text = "MATCH GAME";
            this.btnMatchGame.UseVisualStyleBackColor = true;
            this.btnMatchGame.Click += new System.EventHandler(this.btnMatchGame_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMatchGame);
            this.Controls.Add(this.btnBookGame);
            this.Name = "HomePage";
            this.Text = "HOMEPAGE";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBookGame;
        private System.Windows.Forms.Button btnMatchGame;
    }
}