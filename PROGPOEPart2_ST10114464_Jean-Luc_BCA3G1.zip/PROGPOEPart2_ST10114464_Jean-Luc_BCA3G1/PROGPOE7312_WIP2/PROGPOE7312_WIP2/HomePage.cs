﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROGPOE7312_WIP2
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }
        //-----------------------------------------------------------------------------
        
        //----------------------------------------------------------------------------//
        private void btnBookGame_Click(object sender, EventArgs e)
        {
            //Creating instance of the game form
            Form1 gameForm = new Form1();

            //Shows the form game form
            gameForm.Show();
        }
        //----------------------------------------------------------------------------//

        //--------------------------------------------------------------------------------//
        private void btnMatchGame_Click(object sender, EventArgs e)
        {
            //Creating an instance of form2
            Form2 matchGameForm = new Form2();

            //shows form 2
            matchGameForm.Show();
        }
        //----------------------------------------------------------------------------------//
        
        //-------------------------------------------------------------------------------------//
    }
}
