-- ReadMe File--

--Pereequisites--

Microsoft Visual Studio

.Net Framework


-------Installation------------

1.) Extract the zip folder or the project from the GitHub Repository

2.) Open the project using the Microsoft Visual studio you have installed

-Open visual studio
-Select Open project or solution
-Go to where you saved the download for the program
-Select the file and open it
-Inside the file select the code and it should launch and be readyf or use

3.) Build and compile the application

4.) Run the application from visual studio


-------How to use---------- (DOES NOT RUN)

On startup you will see the main menu where you will have the buttons

- BOOK GAME when pressed this will take the user to the Book Game menu and start the Book Game

- MATCHING GAME when pressed will take the user to the Matching Game page and start the matching game (POE Task 2)



On the Matching Game Button start up you will see 4 buttons:

- Button 1 and 2 will match the columns on the left side
- Button 3 and 4 will match the columns on the right side 
- When the user matches both columns they will score points before the timer ends
- The exit button will close the application
- The back button will take the user to the Home Page



On the Match Books Game Button start up you will buttons:


-Replace books : This button will generate a random list of numbers and names according to the Deweydecimal system
-Sort books : This button acts as the enter button when you press it, it will show the user if they got the order right or wrong and if they got it right thye will be rewarded 10 points
-Add item : This will allow the user to type in the name and number and add it to the list so they can get it in the right order
-Remove item : This will remove the name and number from the list
-Move Up : This will allow the user to select the name and number they wish to either move up list
-Move Down : This button will allow the user to select the name and number the user wants to move down the list

The user has 60 seconds to get as many points as possible, every time they get the order correct in ascending order they are awarded 10 points

-----------------------------

Jean-Luc Le Roux ST10114464

